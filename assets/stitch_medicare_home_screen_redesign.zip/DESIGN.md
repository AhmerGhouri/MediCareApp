---
name: Vitality Core
colors:
  surface: '#f8f9fa'
  surface-dim: '#d9dadb'
  surface-bright: '#f8f9fa'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f4f5'
  surface-container: '#edeeef'
  surface-container-high: '#e7e8e9'
  surface-container-highest: '#e1e3e4'
  on-surface: '#191c1d'
  on-surface-variant: '#44474d'
  inverse-surface: '#2e3132'
  inverse-on-surface: '#f0f1f2'
  outline: '#75777e'
  outline-variant: '#c5c6ce'
  surface-tint: '#4e5f7d'
  primary: '#031631'
  on-primary: '#ffffff'
  primary-container: '#1a2b47'
  on-primary-container: '#8293b4'
  inverse-primary: '#b6c7ea'
  secondary: '#b42814'
  on-secondary: '#ffffff'
  secondary-container: '#fe5d43'
  on-secondary-container: '#5e0600'
  tertiary: '#261100'
  on-tertiary: '#ffffff'
  tertiary-container: '#432300'
  on-tertiary-container: '#d67c00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#b6c7ea'
  on-primary-fixed: '#081b37'
  on-primary-fixed-variant: '#374765'
  secondary-fixed: '#ffdad4'
  secondary-fixed-dim: '#ffb4a6'
  on-secondary-fixed: '#3f0300'
  on-secondary-fixed-variant: '#900e00'
  tertiary-fixed: '#ffdcbf'
  tertiary-fixed-dim: '#ffb874'
  on-tertiary-fixed: '#2d1600'
  on-tertiary-fixed-variant: '#6b3b00'
  background: '#f8f9fa'
  on-background: '#191c1d'
  surface-variant: '#e1e3e4'
typography:
  headline-xl:
    fontFamily: Plus Jakarta Sans
    fontSize: 24px
    fontWeight: '800'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 28px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  margin-main: 20px
  gutter: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
---

## Brand & Style
The design system prioritizes a **Corporate Modern** healthcare aesthetic that balances clinical authority with human warmth. It is designed for patients and medical staff who require immediate clarity, ease of navigation, and a sense of calm. 

The style utilizes a "Functional Softness" approach: high-contrast navy typography ensures accessibility, while pastel-toned surfaces reduce cognitive load and visual anxiety. The interface feels structured yet approachable, moving away from sterile hospital whites toward a more inviting, color-coded environmental design. Use of generous whitespace and soft-edged containers creates a safe, modern digital space.

## Colors
The color strategy employs a **Navy Primary** for structural elements and text to provide high legibility. 

- **Primary & Neutral:** The background is a clean off-white. We use a palette of "Pastel Foundations"—very light washes of Red, Blue, Green, and Yellow—to differentiate functional areas (e.g., Clinics, Appointments, Labs).
- **Accents:** Warm gradients ranging from deep red (#E34A32) to bright orange (#F49322) are reserved for primary calls to action, navigation bars, and critical status indicators.
- **Contextual Colors:** Use subtle pastel backgrounds for cards to categorize content types without overwhelming the user with saturated hues.

## Typography
We use **Plus Jakarta Sans** for its friendly yet professional geometry. 

- **Hierarchy:** Bold weights (700-800) are used for user names and section headers to ensure they anchor the page. 
- **Readability:** Body text uses medium weights to maintain a clean appearance on low-contrast pastel backgrounds. 
- **Labels:** Small, uppercase labels with increased letter spacing are used for metadata (e.g., "DATE", "DOCTOR") to distinguish them from the data they represent.
- **Color:** All primary text should be the Navy primary (#1A2B47) or Navy Muted (#5E6D82). Use White only on high-saturation accent backgrounds.

## Layout & Spacing
This design system follows a **Fluid Grid** model optimized for mobile-first healthcare delivery.

- **Margins:** A standard 20px horizontal margin is applied to the main viewport.
- **Card Padding:** Internal padding for cards should be a consistent 16px.
- **Sectioning:** Use 24px spacing between major functional groups (e.g., between "Quick Actions" and "History").
- **Grid:** Use a 2-column layout for Quick Action cards and a single-column stacked layout for History and record items to allow for horizontal data display.

## Elevation & Depth
The design system utilizes **Tonal Layers** rather than heavy shadows to create depth.

- **Base Layer:** The background is the neutral off-white.
- **Surface Layer:** Cards use flat pastel backgrounds with no shadows to maintain a clean, modern "print" feel.
- **Interactive Layer:** Subtle, highly diffused shadows (4px blur, 4% opacity) are used only for floating elements like the bottom navigation bar or primary action buttons to give them a slight "lift" above the content.
- **Backdrop Blurs:** Use subtle blurs on header backgrounds when content scrolls beneath them to maintain context.

## Shapes
The shape language is defined by **Large Radii** to evoke a sense of friendliness and safety.

- **Primary Containers:** Large feature cards and quick-action blocks use `rounded-xl` (1.5rem / 24px) to create a distinct, modular appearance.
- **Sub-elements:** Inner buttons, search bars, and small icons use `rounded-lg` (1rem / 16px).
- **Navigation:** The bottom navigation bar uses a unique top-radius only (32px) to frame the interface comfortably.
- **Icons:** Icons should be enclosed in "squircle" containers that match the card's pastel tone but with a slightly higher saturation.

## Components

### Buttons & Actions
- **Primary Buttons:** Circular or pill-shaped containers featuring a gradient of Red to Orange. Icons are centered and white.
- **Quick Action Cards:** Two-part components. The top 70% is a pastel color block containing a large icon; the bottom 30% is a white strip with the label and a secondary "arrow" action button.
- **History Cards:** Horizontal cards with a colored header strip. Use a "View Full History" footer link that is visually separated by a thin hairline border.

### Feedback & Inputs
- **Inputs:** Clean white fields with 16px rounded corners and a 1px soft grey border.
- **Chips/Status:** Use the pastel palette for status chips (e.g., "Most Recent"). Text color should be a darker version of the chip's background.

### Navigation
- **Header:** Features a circular profile avatar with a thick colored ring. Action icons (notification, logout) are housed in rounded white squares.
- **Bottom Bar:** A dominant, high-contrast bar with a protruding "Home" button. Use the brand gradient for the background to signify this as the "anchor" of the application.